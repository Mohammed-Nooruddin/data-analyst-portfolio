# Hi, I'm Mohammed Nooruddin

**Data Analyst based in Riyadh, Saudi Arabia.** I turn raw business data into clear answers using SQL, Python and Power BI.

- Background: Bachelor of Commerce (accounting, finance, business statistics)
- Focus: sales analysis, customer segmentation, KPI dashboards and financial reporting
- Open to: Data Analyst, BI Analyst and Reporting Analyst roles in Riyadh

### Featured work

| Project | Tools | Highlight |
|---------|-------|-----------|
| [Retail Sales Analysis with SQL](https://github.com/USERNAME/data-analyst-portfolio/tree/main/01-sql-sales-analysis) | SQL, window functions, CTEs | Cohort retention and Pareto analysis on 541K transactions |
| [Customer Segmentation](https://github.com/USERNAME/data-analyst-portfolio/tree/main/02-customer-segmentation) | Python, pandas, scikit-learn | RFM + K-Means: 26% of customers drive 67% of revenue |
| [Sales Dashboard](https://github.com/USERNAME/data-analyst-portfolio/tree/main/03-powerbi-sales-dashboard) | Power BI, DAX | Star-schema model with KPI and time-intelligence measures |

### Tools

SQL · Python (pandas, NumPy, scikit-learn) · Power BI (DAX, Power Query) · Excel · Jupyter · Git

### Contact

[LinkedIn](https://linkedin.com/in/Nooruddin) · uddinmdnoor7@gmail.com
