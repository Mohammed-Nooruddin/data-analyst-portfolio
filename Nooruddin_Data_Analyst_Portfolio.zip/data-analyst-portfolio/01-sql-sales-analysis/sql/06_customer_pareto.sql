-- 06_customer_pareto.sql
-- What share of revenue comes from the top 10% / 20% of customers?
-- Uses a running total (window SUM) over customers ranked by revenue.
WITH c AS (
    SELECT CustomerID, SUM(Revenue) AS revenue
    FROM sales WHERE CustomerID IS NOT NULL
    GROUP BY CustomerID
),
ranked AS (
    SELECT CustomerID, revenue,
           ROW_NUMBER() OVER (ORDER BY revenue DESC)           AS rn,
           COUNT(*)     OVER ()                                AS n,
           SUM(revenue) OVER (ORDER BY revenue DESC)           AS running_rev,
           SUM(revenue) OVER ()                                AS total_rev
    FROM c
)
SELECT 'Top 1%'  AS segment, ROUND(100.0*MAX(running_rev)/MAX(total_rev),1) AS pct_revenue FROM ranked WHERE rn <= n*0.01
UNION ALL
SELECT 'Top 10%', ROUND(100.0*MAX(running_rev)/MAX(total_rev),1) FROM ranked WHERE rn <= n*0.10
UNION ALL
SELECT 'Top 20%', ROUND(100.0*MAX(running_rev)/MAX(total_rev),1) FROM ranked WHERE rn <= n*0.20;
