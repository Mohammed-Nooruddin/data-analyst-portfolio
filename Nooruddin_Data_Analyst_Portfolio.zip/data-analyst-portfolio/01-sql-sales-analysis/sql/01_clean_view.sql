-- 01_clean_view.sql
-- Build a clean sales view from the raw transactions table.
-- Rules: drop cancelled invoices (InvoiceNo starts with 'C'), negative/zero
-- quantities, zero/negative prices, non-product codes (postage, fees, adjustments)
-- and exact duplicate rows.

DROP VIEW IF EXISTS sales;
CREATE VIEW sales AS
SELECT DISTINCT
    InvoiceNo,
    StockCode,
    TRIM(Description)                 AS Description,
    Quantity,
    InvoiceDate,
    UnitPrice,
    CAST(CustomerID AS INTEGER)       AS CustomerID,
    Country,
    ROUND(Quantity * UnitPrice, 2)    AS Revenue,
    strftime('%Y-%m', InvoiceDate)    AS YearMonth
FROM transactions
WHERE InvoiceNo NOT LIKE 'C%'
  AND Quantity  > 0
  AND UnitPrice > 0
  AND StockCode NOT IN ('POST','DOT','M','D','C2','BANK CHARGES','AMAZONFEE','CRUK','PADS','B','S');
