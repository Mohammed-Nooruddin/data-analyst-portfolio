-- 02_kpi_overview.sql : headline KPIs for the full period
SELECT
    ROUND(SUM(Revenue), 0)                                AS total_revenue,
    COUNT(DISTINCT InvoiceNo)                             AS orders,
    COUNT(DISTINCT CustomerID)                            AS customers,
    COUNT(DISTINCT StockCode)                             AS products,
    COUNT(DISTINCT Country)                               AS countries,
    ROUND(SUM(Revenue) / COUNT(DISTINCT InvoiceNo), 2)    AS avg_order_value
FROM sales;
