-- 03_monthly_revenue_growth.sql
-- Monthly revenue, orders, AOV and month-over-month growth using LAG().
-- December 2011 is excluded because data stops on 9 Dec 2011 (partial month).
WITH monthly AS (
    SELECT YearMonth,
           SUM(Revenue)              AS revenue,
           COUNT(DISTINCT InvoiceNo) AS orders
    FROM sales
    WHERE YearMonth < '2011-12'
    GROUP BY YearMonth
)
SELECT YearMonth,
       ROUND(revenue, 0)                                   AS revenue,
       orders,
       ROUND(revenue / orders, 2)                          AS avg_order_value,
       ROUND(100.0 * (revenue - LAG(revenue) OVER (ORDER BY YearMonth))
             / LAG(revenue) OVER (ORDER BY YearMonth), 1)  AS mom_growth_pct
FROM monthly
ORDER BY YearMonth;
