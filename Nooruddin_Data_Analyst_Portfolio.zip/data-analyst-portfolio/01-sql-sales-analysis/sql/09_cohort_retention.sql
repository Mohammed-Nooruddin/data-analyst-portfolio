-- 09_cohort_retention.sql
-- Monthly cohort retention: of customers whose first purchase was in month X,
-- what % bought again 1, 2, 3 ... months later?
-- Activity in the partial month Dec 2011 is excluded so the last column is not understated.
WITH first_purchase AS (
    SELECT CustomerID, MIN(YearMonth) AS cohort
    FROM sales WHERE CustomerID IS NOT NULL
    GROUP BY CustomerID
),
activity AS (
    SELECT DISTINCT s.CustomerID, f.cohort,
           (CAST(substr(s.YearMonth,1,4) AS INT) - CAST(substr(f.cohort,1,4) AS INT)) * 12
         + (CAST(substr(s.YearMonth,6,2) AS INT) - CAST(substr(f.cohort,6,2) AS INT)) AS month_index
    FROM sales s JOIN first_purchase f USING (CustomerID)
    WHERE s.YearMonth < '2011-12'   -- Dec 2011 is a partial month
),
cohort_size AS (
    SELECT cohort, COUNT(*) AS customers FROM first_purchase GROUP BY cohort
)
SELECT a.cohort, c.customers, a.month_index,
       COUNT(DISTINCT a.CustomerID)                               AS active,
       ROUND(100.0 * COUNT(DISTINCT a.CustomerID) / c.customers, 1) AS retention_pct
FROM activity a JOIN cohort_size c USING (cohort)
WHERE a.cohort < '2011-12'
GROUP BY a.cohort, a.month_index
ORDER BY a.cohort, a.month_index;
