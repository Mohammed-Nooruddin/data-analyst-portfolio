-- 05_revenue_by_country.sql : top 10 markets, share of revenue and AOV
SELECT Country,
       ROUND(SUM(Revenue), 0)                                    AS revenue,
       COUNT(DISTINCT CustomerID)                                AS customers,
       ROUND(SUM(Revenue) / COUNT(DISTINCT InvoiceNo), 2)        AS avg_order_value,
       ROUND(100.0 * SUM(Revenue) / SUM(SUM(Revenue)) OVER (), 2) AS pct_of_total
FROM sales
GROUP BY Country
ORDER BY revenue DESC
LIMIT 10;
