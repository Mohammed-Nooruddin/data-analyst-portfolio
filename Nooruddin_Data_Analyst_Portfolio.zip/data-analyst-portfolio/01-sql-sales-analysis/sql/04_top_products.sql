-- 04_top_products.sql : top 10 products by revenue and their share of total
WITH p AS (
    SELECT StockCode, MAX(Description) AS product,
           SUM(Quantity) AS units, SUM(Revenue) AS revenue
    FROM sales GROUP BY StockCode
)
SELECT RANK() OVER (ORDER BY revenue DESC)                   AS rnk,
       product, units, ROUND(revenue, 0)                     AS revenue,
       ROUND(100.0 * revenue / SUM(revenue) OVER (), 2)      AS pct_of_total
FROM p
ORDER BY revenue DESC
LIMIT 10;
