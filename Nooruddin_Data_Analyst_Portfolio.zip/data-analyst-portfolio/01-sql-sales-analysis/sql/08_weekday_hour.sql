-- 08_weekday_hour.sql : when do customers order? (orders by weekday and hour)
SELECT CASE strftime('%w', InvoiceDate)
         WHEN '0' THEN 'Sun' WHEN '1' THEN 'Mon' WHEN '2' THEN 'Tue'
         WHEN '3' THEN 'Wed' WHEN '4' THEN 'Thu' WHEN '5' THEN 'Fri' ELSE 'Sat' END AS weekday,
       CAST(strftime('%H', InvoiceDate) AS INTEGER) AS hour,
       COUNT(DISTINCT InvoiceNo)                    AS orders,
       ROUND(SUM(Revenue), 0)                       AS revenue
FROM sales
GROUP BY 1, 2
ORDER BY strftime('%w', MIN(InvoiceDate)), hour;
