-- 07_cancellations.sql : how much value is lost to cancelled invoices?
SELECT
    COUNT(DISTINCT CASE WHEN InvoiceNo LIKE 'C%' THEN InvoiceNo END)              AS cancelled_invoices,
    COUNT(DISTINCT InvoiceNo)                                                     AS all_invoices,
    ROUND(100.0 * COUNT(DISTINCT CASE WHEN InvoiceNo LIKE 'C%' THEN InvoiceNo END)
          / COUNT(DISTINCT InvoiceNo), 1)                                         AS cancel_rate_pct,
    ROUND(-SUM(CASE WHEN InvoiceNo LIKE 'C%' AND StockCode NOT IN ('M','D','POST','BANK CHARGES','AMAZONFEE','CRUK')
                    THEN Quantity * UnitPrice END), 0)                            AS cancelled_value
FROM transactions;
