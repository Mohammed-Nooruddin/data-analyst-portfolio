"""Load the raw CSV into SQLite, run every query in sql/ and save results + charts."""
import sqlite3, glob, os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '..', 'data', 'online_retail.zip')  # pandas reads the CSV inside the zip
DB = os.path.join(HERE, 'retail.db')

con = sqlite3.connect(DB)
raw = pd.read_csv(RAW, dtype={'InvoiceNo': str, 'StockCode': str})
raw.to_sql('transactions', con, if_exists='replace', index=False)

results = {}
for path in sorted(glob.glob(os.path.join(HERE, 'sql', '*.sql'))):
    name = os.path.basename(path)[:-4]
    sql = open(path).read()
    if name.startswith('01_'):
        con.executescript(sql); continue
    df = pd.read_sql(sql, con)
    df.to_csv(os.path.join(HERE, 'results', f'{name}.csv'), index=False)
    results[name] = df
    print(f'\n=== {name} ===\n{df.head(15).to_string(index=False)}')

sns.set_theme(style='whitegrid')
NAVY = '#1F3864'

m = results['03_monthly_revenue_growth']
fig, ax = plt.subplots(figsize=(10, 4.5))
ax.bar(m.YearMonth, m.revenue / 1000, color=NAVY)
ax.set_title('Monthly revenue (£ thousands), Dec 2010 – Nov 2011')
ax.set_ylabel('£ thousands'); plt.xticks(rotation=45); fig.tight_layout()
fig.savefig(os.path.join(HERE, 'charts', 'monthly_revenue.png'), dpi=150)

c = results['05_revenue_by_country'].iloc[1:]
fig, ax = plt.subplots(figsize=(9, 4.5))
ax.barh(c.Country[::-1], c.revenue[::-1] / 1000, color=NAVY)
ax.set_title('Top international markets by revenue (excluding UK), £ thousands')
fig.tight_layout(); fig.savefig(os.path.join(HERE, 'charts', 'top_countries.png'), dpi=150)

r = results['09_cohort_retention']
pivot = r.pivot(index='cohort', columns='month_index', values='retention_pct')
fig, ax = plt.subplots(figsize=(11, 6))
sns.heatmap(pivot, annot=True, fmt='.0f', cmap='Blues', cbar_kws={'label': 'Retention %'}, ax=ax)
ax.set_title('Monthly cohort retention (%)'); ax.set_xlabel('Months since first purchase'); ax.set_ylabel('Cohort')
fig.tight_layout(); fig.savefig(os.path.join(HERE, 'charts', 'cohort_retention.png'), dpi=150)

w = results['08_weekday_hour']
heat = w.pivot_table(index='weekday', columns='hour', values='orders', aggfunc='sum').reindex(['Mon','Tue','Wed','Thu','Fri','Sat','Sun']).dropna(how='all')
fig, ax = plt.subplots(figsize=(11, 3.8))
sns.heatmap(heat, cmap='Blues', annot=True, fmt='.0f', ax=ax, cbar=False)
ax.set_title('Number of orders by weekday and hour'); fig.tight_layout()
fig.savefig(os.path.join(HERE, 'charts', 'orders_weekday_hour.png'), dpi=150)
con.close()
