# Retail Sales Analysis with SQL

Analysis of **541,909 real transactions** from a UK-based online gift retailer (Dec 2010 – Dec 2011) using **SQL (SQLite)**, with Python used only to load the data and draw charts.

**Business question:** Where does revenue come from, how loyal are customers, and where should the business focus to grow?

## Key findings

| # | Finding | So what? |
|---|---------|----------|
| 1 | **Strong Q4 seasonality** – Sep–Nov 2011 produced **37%** of the year's revenue; November alone (£1.45M) was **120% above** the Jan–Aug monthly average. | Plan stock, staffing and marketing budget for Q4 from August. |
| 2 | **Revenue is concentrated** – the top **10%** of customers generate **61%** of revenue, and the top **1%** generate **32%**. | A key-account / VIP programme protects most of the revenue. |
| 3 | **Retention is the main weakness** – on average only **21%** of new customers buy again the next month. | Improve onboarding and second-purchase offers. |
| 4 | **The first cohort (Dec 2010) is the most loyal** – 32–50% of them stay active every month for a year. | Study what makes these customers different and target look-alikes. |
| 5 | **UK = 85% of revenue**, but the Netherlands and Australia have average orders of **£3,053** and **£2,466** vs £487 in the UK. | Large B2B buyers abroad: an opportunity for international account management. |
| 6 | **14.8% of invoices are cancelled**, worth about **£482K**. | Investigate cancellation reasons (stock, delivery, errors). |
| 7 | **Orders peak Tue–Thu, 10:00–15:00**, there are no Saturday orders. | Schedule campaigns and customer support around these hours. |

## Charts

![Monthly revenue](charts/monthly_revenue.png)
![Cohort retention](charts/cohort_retention.png)
![Top international markets](charts/top_countries.png)
![Orders by weekday and hour](charts/orders_weekday_hour.png)

## SQL skills shown

| File | What it does | Techniques |
|------|--------------|-----------|
| `01_clean_view.sql` | Cleans the raw data into a `sales` view | Filtering, `DISTINCT`, calculated columns, date functions |
| `02_kpi_overview.sql` | Headline KPIs: revenue, orders, customers, AOV | Aggregation |
| `03_monthly_revenue_growth.sql` | Monthly revenue and month-over-month growth | CTE, `LAG()` window function |
| `04_top_products.sql` | Top 10 products and share of revenue | `RANK()`, `SUM() OVER ()` |
| `05_revenue_by_country.sql` | Revenue, customers and AOV by country | `GROUP BY`, window share of total |
| `06_customer_pareto.sql` | Revenue share of top 1% / 10% / 20% customers | `ROW_NUMBER()`, running totals, `UNION ALL` |
| `07_cancellations.sql` | Cancellation rate and lost value | Conditional aggregation (`CASE WHEN`) |
| `08_weekday_hour.sql` | When customers place orders | Date functions, `CASE` |
| `09_cohort_retention.sql` | Monthly cohort retention table | Multiple CTEs, `JOIN`, date arithmetic |

## Data cleaning rules

- Removed cancelled invoices (`InvoiceNo` starting with `C`), negative quantities and zero prices
- Removed non-product codes (postage, bank charges, manual adjustments, Amazon fees)
- Removed 5,268 exact duplicate rows
- Customer-level analysis uses only rows with a `CustomerID` (about 25% of rows have none)
- December 2011 is a partial month (data ends 9 Dec), so it is excluded from trend and retention analysis

## How to run

```bash
pip install pandas matplotlib seaborn openpyxl
python run_analysis.py
```

The script loads `data/online_retail.zip` into SQLite, runs each file in `sql/` in order, saves the outputs to `results/` and the charts to `charts/`.

## Data source

[Online Retail dataset](https://archive.ics.uci.edu/dataset/352/online+retail), UCI Machine Learning Repository (Chen, D. 2015), licensed CC BY 4.0. All values are in GBP.
