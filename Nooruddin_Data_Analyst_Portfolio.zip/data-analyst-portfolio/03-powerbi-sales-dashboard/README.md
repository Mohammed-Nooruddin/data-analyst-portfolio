# Retail Sales & Customer Dashboard – Power BI

An interactive **Power BI** dashboard for a UK online retailer (£10.2M revenue, 19,773 orders, 4,334 customers, 38 countries) built on a **star-schema data model** with **DAX measures** for KPIs, time intelligence and customer segments.

> **Screenshot:** add `screenshots/overview.png` after you build the report.
>
> ![Dashboard overview](screenshots/overview.png)

## What the dashboard answers

- How are revenue, orders and average order value trending month by month?
- Which products and countries drive revenue?
- Which customer segments (from the RFM analysis) bring the most value?
- How much revenue is lost to cancellations?

## Data model (star schema)

```
                 dim_date (Date)
                       │ 1
                       │
                       ▼ *
dim_product ──1──*  fact_sales  *──1── dim_customer
 (StockCode)       531K rows           (CustomerID, RFM_Segment)
```

| Table | Rows | Key columns |
|-------|-----:|-------------|
| `fact_sales` | 531,237 | InvoiceNo, Date, Hour, StockCode, CustomerID, Country, Quantity, UnitPrice, Revenue, IsCancelled |
| `dim_product` | 3,927 | StockCode, Product |
| `dim_customer` | 4,363 | CustomerID, Country, Recency, Frequency, Monetary, RFM_Segment, Cluster_Name |
| `dim_date` | 396 | Date, Year, Quarter, MonthNo, Month, YearMonth, Weekday, WeekdayNo |

All DAX measures are in [`dax_measures.dax`](dax_measures.dax).

---

## Build guide (about 2–3 hours)

### Step 1 – Load the data
1. Open **Power BI Desktop** → **Get Data → Text/CSV**.
2. First **unzip `data/fact_sales.zip`** (GitHub limits file size), then load the four CSV files from the `data/` folder.
3. In **Power Query**, check the data types:
   - `fact_sales[Date]` and `dim_date[Date]` → **Date**
   - `Revenue`, `UnitPrice` → **Decimal number**; `Quantity`, `Hour`, `CustomerID` → **Whole number**
   - `IsCancelled` → **True/False**
   - `StockCode` → **Text** (important: some codes contain letters)
4. Click **Close & Apply**.

### Step 2 – Build the model
1. Go to **Model view** and create these relationships (one-to-many, single direction):
   - `dim_date[Date]` → `fact_sales[Date]`
   - `dim_product[StockCode]` → `fact_sales[StockCode]`
   - `dim_customer[CustomerID]` → `fact_sales[CustomerID]`
2. Select `dim_date` → **Mark as date table** → choose `Date`.
3. Sort `dim_date[Month]` by `MonthNo` and `dim_date[Weekday]` by `WeekdayNo` (**Column tools → Sort by column**).
4. Hide the key columns in `fact_sales` (Date, StockCode, CustomerID) so users only filter through dimension tables.

### Step 3 – Add DAX measures
1. **Home → Enter data** → create an empty table named `_Measures`.
2. Copy each measure from `dax_measures.dax` into **New measure**.
3. Format: currency measures as **£ #,0**, percentages as **%** with 1 decimal.

### Step 4 – Build the report pages

**Page 1 – Sales Overview**
- 5 KPI cards: Total Revenue, Orders, Customers, Avg Order Value, Cancellation Rate %
- Line + column chart: `YearMonth` vs Total Revenue (columns) and Revenue 3M Rolling Avg (line)
- Bar chart: top 10 products by Total Revenue (use a **Top N** filter)
- Filled map or bar chart: Total Revenue by Country
- Slicers: Year/Month, Country

**Page 2 – Customers**
- Donut or bar: Total Revenue by `RFM_Segment`
- Table: RFM_Segment, Customers, Total Revenue, % of Total Revenue, Revenue per Customer
- Scatter: Recency (x) vs Monetary (y), legend `Cluster_Name`
- Matrix heatmap: Weekday (rows) × Hour (columns), value Orders, with conditional formatting

**Page 3 – Cancellations & Markets**
- Cards: Cancelled Orders, Cancelled Value
- Line chart: Cancellation Rate % by month
- Table: Country, Total Revenue, Avg Order Value, International Revenue %

### Step 5 – Polish
- One colour theme (e.g. navy `#1F3864` plus greys), same font everywhere
- Title on each page; add the `Dashboard Subtitle` measure in a card under the title
- Add tooltips and turn on **Edit interactions** so charts filter each other sensibly
- Check that every number matches: **Total Revenue = £10,247,908** and **Orders = 19,773** for the full period

### Step 6 – Publish
1. Save as `Retail_Sales_Dashboard.pbix` in this folder.
2. Export each page as an image (**File → Export → PDF**, then screenshot) into `screenshots/`.
3. Optional: **Publish to web** (free Power BI account) and add the public link here: **Live report:** _add link_

---

## Expected insights (from the SQL and Python analysis)

- Sep–Nov produce **37%** of yearly revenue (strong Q4 seasonality)
- Champions (26% of customers) generate **67%** of revenue
- UK = **85%** of revenue; the Netherlands and Australia have the largest average orders
- **14.8%** of invoices are cancelled

## Data source

[Online Retail dataset](https://archive.ics.uci.edu/dataset/352/online+retail), UCI Machine Learning Repository (Chen, D. 2015), licensed CC BY 4.0. Prepared from the cleaned data used in projects 1 and 2.
