# Data Analyst Portfolio – Mohammed Nooruddin

Three end-to-end projects on the same real business dataset (541,909 transactions from an online retailer). Together they show the full analyst workflow: **SQL → Python → Power BI → business recommendations**.

| # | Project | Tools | Key result |
|---|---------|-------|-----------|
| 1 | [Retail Sales Analysis with SQL](01-sql-sales-analysis/) | SQL (CTEs, window functions), Python for charts | Found that 10% of customers bring 61% of revenue and only 21% of new customers return the next month |
| 2 | [Customer Segmentation – RFM & K-Means](02-customer-segmentation/) | Python, pandas, scikit-learn | Segmented 4,334 customers; Champions (26%) bring 67% of revenue; £783K "At Risk" revenue identified for win-back |
| 3 | [Sales & Customer Dashboard](03-powerbi-sales-dashboard/) | Power BI, DAX, star-schema model | Interactive dashboard with KPIs, time intelligence and customer segments |

## Skills

**SQL:** joins, CTEs, window functions (LAG, RANK, ROW_NUMBER, running totals), cohort analysis
**Python:** pandas, NumPy, Matplotlib, Seaborn, scikit-learn (K-Means), Jupyter
**Power BI:** data modelling (star schema), Power Query, DAX, time intelligence, dashboard design
**Excel:** advanced formulas, PivotTables, Power Query
**Business:** KPI design, customer segmentation, retention analysis, clear recommendations

## Repository structure

```
data/                         raw dataset (zipped CSV)
01-sql-sales-analysis/        SQL queries, results, charts
02-customer-segmentation/     Jupyter notebook, segment output, charts
03-powerbi-sales-dashboard/   Power BI model data, DAX measures, build guide
```

## Contact

Riyadh, Saudi Arabia · [LinkedIn](https://linkedin.com/in/Nooruddin) · uddinmdnoor7@gmail.com

Data: [UCI Online Retail dataset](https://archive.ics.uci.edu/dataset/352/online+retail) (CC BY 4.0).
