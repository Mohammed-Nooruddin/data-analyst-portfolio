# Customer Segmentation – RFM Analysis and K-Means Clustering

Segmenting **4,334 customers** of a UK online retailer by purchasing behaviour, using **Python (pandas, scikit-learn)**, so marketing can target each group with the right action.

**Business question:** Who are our most valuable customers, who is about to leave, and how should we treat each group?

## Approach

1. **Clean** 541,909 transactions → 391,150 valid rows (removed cancellations, returns, missing customer IDs, non-product codes, duplicates)
2. **RFM** for every customer: Recency (days since last order), Frequency (number of orders), Monetary (total spend)
3. **Rule-based segments** using 1–5 quintile scores (easy for business teams to use)
4. **K-Means clustering** on log-transformed, standardised RFM; *k* chosen with the elbow method and silhouette score
5. **Profile** each segment and recommend actions

## Key findings

**RFM segments**

| Segment | Customers | % of customers | % of revenue | Avg spend | Recommended action |
|---------|----------:|---------------:|-------------:|----------:|--------------------|
| Champions | 1,136 | 26.2% | **66.7%** | £5,130 | VIP programme, early access, ask for referrals |
| Loyal | 827 | 19.1% | 15.0% | £1,589 | Loyalty rewards, cross-sell |
| At Risk | 637 | 14.7% | 9.0% | £1,230 | Win-back campaign now (last order ~5 months ago) |
| Lost / Hibernating | 1,068 | 24.6% | 5.8% | £478 | Low-cost reactivation email only |
| Need Attention | 347 | 8.0% | 1.8% | £459 | Limited-time offer |
| New / Promising | 319 | 7.4% | 1.6% | £446 | Onboarding and second-purchase discount |

- **About a quarter of customers (Champions) bring two-thirds of the revenue.** Losing even a few of them hurts.
- **At Risk customers are worth about £783K.** They used to buy regularly but have not ordered for ~5 months, so they are the best target for a win-back campaign.
- **K-Means found 4 natural clusters** that match the rules: a VIP group (686 customers, **64%** of revenue, median 10 orders), regular mid-value buyers, new/recent buyers and a large low-value/lapsed group (1,636 customers, only 6.5% of revenue).

![RFM segments](charts/rfm_segments.png)
![Clusters](charts/clusters_scatter.png)

## Files

| File | Description |
|------|-------------|
| `customer_segmentation.ipynb` | Full analysis notebook with code, charts and explanations |
| `customer_segments.csv` | Every customer with RFM values, scores, segment and cluster (ready for Power BI or a CRM) |
| `charts/` | Exported charts |

## Skills shown

Data cleaning · feature engineering · RFM analysis · log transformation and scaling · K-Means clustering · elbow and silhouette methods · data visualisation · business recommendations

## How to run

```bash
pip install pandas numpy matplotlib seaborn scikit-learn jupyter
jupyter notebook customer_segmentation.ipynb
```

## Data source

[Online Retail dataset](https://archive.ics.uci.edu/dataset/352/online+retail), UCI Machine Learning Repository (Chen, D. 2015), licensed CC BY 4.0.
